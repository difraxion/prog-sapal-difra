<div data="transparencia">
	<div data-cycle-fx="scrollHorz" data-cycle-slides="&gt; div" data-cycle-timeout="4000" data-cycle-speed="1000" data-cycle-swipe="true" data-cycle-pager=".cycle-pager" data-cycle-pager-template="&lt;span&gt;&lt;/span&gt;" class="cycle-slideshow">
		{BANNERS}
	</div>
	<div class="cycle-pager pa tac wrapper"></div>
	<div class="wrapper">	
		<section data="titleleytrans" >
			<h1>información Actualizada al: 14/10/2013</h1>
		</section>
		<section data="content-general">
			<article data="organigrama">
				<header>
					<h1>El sistema de premios, estímulos y recompensas de conformidad con la Ley de la materia. (no aplica)</h1>
				</header>
				<section>
					<div class="contentindo">
						<p>SAPAL no otorga estímulos ni recompensas; de hacerlo en un futuro se estará a lo dispuesto en el artículo 92 de la LEY PARA EL EJERCICIO Y CONTROL DE LOS RECURSOS PÚBLICOS PARA EL ESTADO Y LOS MUNICIPIOS DE GUANAJUATO.</p>
					</div>	
				</section>
				<div>
					<a href="{DIR}transparencia/leydetransparencia"><span class="pa db"></span>Regresar al Menú</a>
				</div>
			</article>
		</section>
		<?php include 'mod/sectionAvisos.php'; ?>
	</div>
</div>